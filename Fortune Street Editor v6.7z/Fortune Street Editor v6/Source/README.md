FortuneAvenue
=============

Fortune Street editor.  Continuation of the editor released at <http://www.gamefaqs.com/boards/632973-fortune-street/61369903?page=7>.